import django_filters
from django import forms
from helloworld.models import post


class PostFilter(django_filters.FilterSet):
    created_on = django_filters.DateTimeFilter(widget = forms.DateInput(attrs={'type':'date'}) , lookup_expr="date exact")

    class Meta:
        model = post
        fields = ['created_on']